package src.datastructure.unionfind;

/**
 * Pleceholder class for a generic union find set.
 */
public interface UFset {

}
